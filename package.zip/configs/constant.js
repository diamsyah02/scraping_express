const BASE_URL = `https://www.detik.com/`

module.exports = { BASE_URL }